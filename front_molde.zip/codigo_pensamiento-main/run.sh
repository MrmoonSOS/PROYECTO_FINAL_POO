#!/bin/bash

# Campus Food Hub - Script de inicio

echo "🍜 Iniciando Campus Food Hub..."
echo ""

# Verificar que Python esté disponible
if ! command -v python3 &> /dev/null; then
    echo "❌ Error: Python 3 no está instalado"
    exit 1
fi

echo "✓ Python encontrado"
echo ""

# Cambiar al directorio del script
cd "$(dirname "$0")" || exit

# Ejecutar el servidor
echo "🚀 Servidor iniciándose en http://127.0.0.1:8000"
echo ""
echo "Presiona Ctrl+C para detener"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

python3 app.py
