# 🔍 Filtros Inteligentes - Guía Completa

## ¿Cómo Funcionan?

Los **filtros inteligentes NO tienen botón de submit** porque trabajan en **tiempo real automáticamente**.

### El Proceso (Automático)

```
Escribes en un filtro
    ↓
El sistema espera 0.5 segundos (para no saturar)
    ↓
Se ejecuta la búsqueda
    ↓
El menú se actualiza instantáneamente
    ↓
Ves los resultados filtrados
```

**No necesitas hacer clic en nada. Solo escribe o marca checkboxes y verás los cambios inmediatamente.**

---

## 📝 Los 5 Filtros Disponibles

### 1️⃣ **Búsqueda** (Escribe)
- **Qué busca:** Nombre del plato, restaurante o categoría
- **Cómo funciona:** Mientras escribes, se filtra automáticamente
- **Ejemplos:**
  - "bowl" → Encuentra: Bowl Andino, Tofu Fire Bowl
  - "pasta" → Encuentra: Pasta Pomodoro
  - "Casa Pasta" → Encuentra todos los platos de ese restaurante

**RESULTADO:** Solo muestra platos que coinciden con tu búsqueda

---

### 2️⃣ **Precio Máximo** (Número)
- **Qué hace:** Filtra solo platos que cuesten hasta ese precio
- **Incluye descuentos:** Si un plato tiene oferta, considera el precio FINAL (con descuento aplicado)
- **Ejemplo:**
  - Escribes: 15000
  - Muestra: Todos los platos que cuesten $15.000 o menos
  - Nota: Si un plato cuesta $20.000 pero tiene 30% de descuento = $14.000 final, SÍ aparece

**RESULTADO:** Menú filtrado por presupuesto

---

### 3️⃣ **Tiempo Máximo** (Minutos)
- **Qué hace:** Solo muestra platos rápidos de preparar
- **Útil para:** Cuando tienes poco tiempo entre clases
- **Ejemplo:**
  - Escribes: 10
  - Muestra: Platos que tardan 10 minutos o menos
  - Excluye: Pasta Pomodoro (15 min), Lasaña (17 min)

**RESULTADO:** Solo platos rápidos

---

### 4️⃣ **Solo Opciones Saludables** (Checkbox)
- **Qué hace:** Filtra solo platos nutritivos y balanceados
- **Ejemplo:**
  - Sin marcar: 12 platos
  - Marcado: 5 platos saludables
  
**Platos saludables son:**
- Bowl Andino ✓
- Wrap Proteico ✓
- Ensalada Crunch ✓
- Tofu Fire Bowl ✓
- Ravioli Ricotta ✓

**RESULTADO:** Menú "limpio" solo con opciones fit

---

### 5️⃣ **Solo Ofertas de Excedentes** (Checkbox)
- **Qué hace:** Filtra solo platos con descuentos activos
- **Ejemplo:**
  - Sin marcar: 12 platos
  - Marcado: 7 platos con descuento

**RESULTADO:** Solo ofertas (descuentos hasta -35%)

---

## 🎯 Cómo Usarlos Juntos

Puedes **combinar múltiples filtros** y funcionarán juntos:

### Ejemplo 1: "Quiero algo rápido, barato y saludable"
```
Tiempo máximo: 10
Precio máximo: 14000
Marca: Solo opciones saludables
```
**Resultado:** Te mostrará solo platos rápidos, económicos y saludables

### Ejemplo 2: "Busco una oferta"
```
Marca: Solo ofertas de excedentes
```
**Resultado:** Las 7 ofertas disponibles

### Ejemplo 3: "Dame de todo"
```
Búsqueda: (vacío)
Precio: (vacío)
Tiempo: (vacío)
Checkboxes: (desmarcados)
```
**Resultado:** Los 12 platos completos

---

## ⚡ Feedback Visual

Cuando aplicas filtros, verás:

```
10 opciones disponibles ahora
(filtros: búsqueda: "bowl", precio ≤ $15000)
```

Este texto te muestra:
- **10 opciones** = Cuántos platos coinciden
- **filtros activos** = Qué estás filtrando exactamente

---

## 🔄 Cómo Borrar Filtros

Simplemente:
- **Borra el texto** en búsqueda
- **Borra el número** en precio/tiempo
- **Desmarca los checkboxes**

**Instantáneamente verás todos los 12 platos de nuevo**

---

## 💡 Casos de Uso Reales

### Caso 1: Tengo 5 minutos antes de clase
```
Tiempo máximo: 5
```
→ Encuentras solo: Combo Café (3 min), Croissant (4 min), Sandwich (5 min)

### Caso 2: Solo tengo $10.000
```
Precio máximo: 10000
```
→ Encuentras: Croissant ($7.900), Combo Café ($9.900), etc.

### Caso 3: Quiero ahorrar (ofertas)
```
Marca: Solo ofertas de excedentes
```
→ Encuentras 7 descuentos, el máximo es -35%

### Caso 4: Soy vegetariano, tengo presupuesto de $20k
```
Búsqueda: salad o tofu
Precio máximo: 20000
```
→ Encuentras opciones vegetarianas dentro de presupuesto

---

## ❓ Preguntas Frecuentes

### P: ¿Por qué no hay botón "Filtrar"?
R: Es automático. Es más rápido que hacer clic cada vez.

### P: ¿Qué pasa si pongo un precio muy bajo?
R: Si nadie cuesta eso, verás "No encontramos platos con esos filtros"

### P: ¿Los descuentos cuentan para el filtro de precio?
R: **SÍ**. Si pones máximo $15.000, muestra platos cuyo precio FINAL (con descuento) sea ≤ $15.000

### P: ¿Puedo combinar "Búsqueda" + "Saludables" + "Ofertas"?
R: **SÍ**. Todos los filtros trabajan juntos.

### P: ¿Qué pasa si no hay resultados?
R: Ves un mensaje: "No encontramos platos con esos filtros. Prueba ampliando presupuesto o tiempo."

---

## 🎬 Resumen en 3 Pasos

1. **Escribe o marca lo que quieres** (no necesitas botón)
2. **El sistema filtra automáticamente en 0.5 segundos**
3. **Ves los resultados actualizados al instante**

**Es así de simple. Sin submit, sin clics extra. Solo escribe y recibe.**

---

**¿Quieres combinar filtros? Hazlo. El sistema entiende que quieres platos que cumplan TODOS los criterios.**

Ejemplo:
```
Búsqueda: "bowl"
AND
Precio máximo: 15000
AND
Tiempo máximo: 12
AND
Solo saludables: ✓
```

↓

**Te muestra bowls de máximo $15.000, listos en 12 minutos, y que sean saludables**

