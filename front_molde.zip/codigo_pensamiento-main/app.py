from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, dataclass
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse


BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "campus_food.db"
SCHEMA_PATH = BASE_DIR / "schema.sql"
STATIC_DIR = BASE_DIR / "static"


@dataclass
class MenuFilters:
    max_price: int | None = None
    healthy_only: bool = False
    max_time: int | None = None
    search: str = ""
    surplus_only: bool = False
    profile: str = "balance"


def get_connection() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database() -> None:
    connection = get_connection()
    with SCHEMA_PATH.open("r", encoding="utf-8") as schema_file:
        connection.executescript(schema_file.read())

    existing = connection.execute("SELECT COUNT(*) AS total FROM restaurants").fetchone()["total"]
    if existing == 0:
        seed_database(connection)

    connection.commit()
    connection.close()


def seed_database(connection: sqlite3.Connection) -> None:
    restaurants = [
        ("Origen Verde", "Bowls", 12, 9.1, 4.8, 1, "Bloque 12 · Cafetería Norte", "#0d8b6a"),
        ("Casa Pasta", "Italiano", 18, 7.4, 4.7, 1, "Plazoleta Central", "#b64b2d"),
        ("Wok Relay", "Asiático", 10, 8.2, 4.6, 1, "Bloque 7 · Torre Norte", "#d48b00"),
        ("Pan de Barrio", "Panadería", 6, 7.9, 4.5, 1, "Biblioteca Central", "#7c4dca"),
        ("Sabor Paisa", "Tradicional", 14, 6.8, 4.6, 1, "Bloque 4 · Cafetería Sur", "#c92a3d"),
        ("Verde Vivo", "Vegetariano", 11, 9.4, 4.7, 1, "Plazoleta Central", "#2e8b57"),
    ]
    connection.executemany(
        """
        INSERT INTO restaurants
            (name, cuisine, eta_minutes, health_score, rating, is_open, location_label, accent_color)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        restaurants,
    )

    menu_items = [
        # Origen Verde (1) - Bowls
        (1, "Bowl Andino", "Quinoa, pollo al limón y vegetales asados con aderezo de cilantro.", 18900, "almuerzo", 540, 11, 1, 16, 0, None, 1),
        (1, "Wrap Proteico", "Tortilla integral con pavo, hummus y hojas frescas.", 14900, "rápido", 430, 8, 1, 20, 15, "16:00", 0),
        (1, "Ensalada Crunch", "Mix de kale, garbanzos crocantes y vinagreta cítrica.", 13900, "saludable", 380, 7, 1, 10, 20, "15:30", 0),
        (1, "Poke Bowl Salmón", "Salmón fresco, arroz, aguacate, edamame y salsa ponzu.", 22900, "premium", 620, 12, 1, 8, 0, None, 1),

        # Casa Pasta (2) - Italiano
        (2, "Pasta Pomodoro", "Penne artesanal con salsa de tomates rostizados y albahaca.", 16900, "almuerzo", 610, 15, 0, 14, 0, None, 0),
        (2, "Lasaña Express", "Porción lista para recoger con ensalada lateral.", 20900, "destacado", 720, 17, 0, 8, 10, "14:45", 1),
        (2, "Ravioli Ricotta", "Relleno de ricotta y espinaca con mantequilla de salvia.", 21900, "especial", 680, 18, 1, 5, 0, None, 0),
        (2, "Pizza Margherita", "Masa madre, mozzarella fresca, tomate San Marzano y albahaca.", 19900, "almuerzo", 720, 14, 0, 12, 0, None, 1),

        # Wok Relay (3) - Asiático
        (3, "Wok de Pollo", "Arroz jazmín, vegetales crunchy y salsa teriyaki ligera.", 17900, "almuerzo", 590, 10, 0, 18, 0, None, 1),
        (3, "Ramen Corto", "Caldo suave, huevo marinado y noodles frescos.", 19500, "sopa", 640, 12, 0, 12, 0, None, 0),
        (3, "Tofu Fire Bowl", "Tofu crocante, arroz integral y vegetales picantes.", 15900, "vegano", 510, 9, 1, 9, 25, "17:30", 0),
        (3, "Gyozas (8u)", "Empanadas japonesas de cerdo y vegetales con salsa ponzu.", 13900, "snack", 420, 8, 0, 16, 0, None, 0),

        # Pan de Barrio (4) - Panadería
        (4, "Sandwich Campesino", "Pan masa madre, queso campesino y tomates confitados.", 12900, "rápido", 470, 5, 0, 22, 30, "18:00", 1),
        (4, "Croissant de Almendra", "Horneado del día con relleno suave.", 7900, "snack", 320, 4, 0, 15, 35, "17:00", 0),
        (4, "Combo Café + Roll", "Americano mediano con rollo de canela.", 9900, "combo", 410, 3, 0, 30, 20, "16:30", 0),
        (4, "Tostado Jamón y Queso", "Pan brioche tostado con jamón serrano y queso fundido.", 10900, "rápido", 480, 6, 0, 18, 0, None, 0),

        # Sabor Paisa (5) - Tradicional
        (5, "Bandeja Paisa Light", "Versión ligera con frijoles, arroz, carne molida y aguacate.", 19900, "almuerzo", 780, 14, 0, 14, 0, None, 1),
        (5, "Arepa Rellena", "Arepa de maíz rellena con quesito y carne desmechada.", 11900, "rápido", 520, 7, 0, 20, 10, "16:00", 0),
        (5, "Sancocho Trifásico", "Sopa tradicional con tres carnes y vegetales.", 17900, "sopa", 690, 16, 0, 10, 0, None, 0),
        (5, "Empanadas (4u)", "Cuatro empanadas crocantes con ají picante.", 8900, "snack", 460, 6, 0, 25, 20, "17:00", 0),

        # Verde Vivo (6) - Vegetariano
        (6, "Buddha Bowl", "Quinoa, lentejas, vegetales asados y aderezo tahini.", 16900, "saludable", 510, 10, 1, 15, 0, None, 1),
        (6, "Falafel Wrap", "Wrap integral con falafel, hummus, ensalada y tabule.", 14900, "rápido", 490, 8, 1, 18, 15, "15:45", 0),
        (6, "Smoothie Verde", "Espinaca, manzana verde, jengibre, limón y chía.", 8900, "bebida", 220, 4, 1, 25, 0, None, 0),
        (6, "Brownie Vegano", "Postre sin lácteos ni huevo, endulzado con dátiles.", 6900, "snack", 280, 3, 1, 12, 30, "17:30", 0),
    ]
    connection.executemany(
        """
        INSERT INTO menu_items
            (
                restaurant_id, name, description, price_cop, category, calories, prep_time_minutes,
                is_healthy, inventory, surplus_discount_percent, available_until, is_featured
            )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        menu_items,
    )

    user_profiles = [
        ("balance", "⚖️ Balance diario", 18000, 0.5, 0.5, "Bowls", "sin restricciones"),
        ("healthy", "💪 Fit rápido", 17000, 0.9, 0.8, "Bowls", "alto en proteína"),
        ("budget", "💰 Ahorro total", 12000, 0.3, 0.7, "Panadería", "económico"),
        ("comfort", "🍝 Antojo del día", 23000, 0.2, 0.4, "Italiano", "sin restricciones"),
        ("vegan", "🌱 Vegetariano", 17000, 0.95, 0.6, "Vegetariano", "sin carne"),
    ]
    connection.executemany(
        """
        INSERT INTO user_profiles
            (slug, label, budget_cap, health_focus, speed_focus, favorite_cuisine, dietary_tag)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        user_profiles,
    )


def parse_bool(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "si"}


def to_currency(value: int) -> str:
    return f"${value:,.0f}".replace(",", ".")


def safe_int(value: str | None) -> int | None:
    if not value:
        return None
    try:
        result = int(value)
        return result if result > 0 else None
    except (TypeError, ValueError):
        return None


def build_filters(query: dict[str, list[str]]) -> MenuFilters:
    def pick(name: str) -> str | None:
        values = query.get(name)
        return values[0] if values else None

    return MenuFilters(
        max_price=safe_int(pick("max_price")),
        healthy_only=parse_bool(pick("healthy")),
        max_time=safe_int(pick("max_time")),
        search=(pick("search") or "").strip()[:80],  # limitar longitud
        surplus_only=parse_bool(pick("surplus")),
        profile=(pick("profile") or "balance").strip(),
    )


def fetch_profile(connection: sqlite3.Connection, slug: str) -> sqlite3.Row:
    profile = connection.execute(
        "SELECT * FROM user_profiles WHERE slug = ?",
        (slug,),
    ).fetchone()
    return profile or connection.execute("SELECT * FROM user_profiles WHERE slug = 'balance'").fetchone()


def serialize_menu_item(row: sqlite3.Row) -> dict[str, Any]:
    discount = row["surplus_discount_percent"] or 0
    discounted_price = int(row["price_cop"] * (100 - discount) / 100)
    return {
        "id": row["id"],
        "restaurantId": row["restaurant_id"],
        "restaurant": row["restaurant_name"],
        "restaurantAccent": row["accent_color"],
        "restaurantCuisine": row["cuisine"],
        "restaurantLocation": row["location_label"],
        "restaurantEta": row["eta_minutes"],
        "restaurantRating": row["rating"],
        "name": row["name"],
        "description": row["description"],
        "price": row["price_cop"],
        "priceLabel": to_currency(row["price_cop"]),
        "discountedPrice": discounted_price,
        "discountedPriceLabel": to_currency(discounted_price),
        "category": row["category"],
        "calories": row["calories"],
        "prepTime": row["prep_time_minutes"],
        "healthy": bool(row["is_healthy"]),
        "inventory": row["inventory"],
        "surplusDiscount": discount,
        "availableUntil": row["available_until"],
        "featured": bool(row["is_featured"]),
        "isSurplus": discount > 0,
    }


def query_menu_items(connection: sqlite3.Connection, filters: MenuFilters) -> list[dict[str, Any]]:
    conditions = ["r.is_open = 1", "m.inventory > 0"]
    params: list[Any] = []

    if filters.max_price is not None:
        # Filtramos por el precio FINAL que pagará el usuario (incluyendo descuentos)
        conditions.append("(m.price_cop * (100 - m.surplus_discount_percent) / 100) <= ?")
        params.append(filters.max_price)
    if filters.healthy_only:
        conditions.append("m.is_healthy = 1")
    if filters.max_time is not None:
        conditions.append("m.prep_time_minutes <= ?")
        params.append(filters.max_time)
    if filters.search:
        conditions.append("(LOWER(m.name) LIKE ? OR LOWER(r.name) LIKE ? OR LOWER(m.category) LIKE ?)")
        term = f"%{filters.search.lower()}%"
        params.extend([term, term, term])
    if filters.surplus_only:
        conditions.append("m.surplus_discount_percent > 0")

    sql = f"""
        SELECT
            m.*,
            r.name AS restaurant_name,
            r.cuisine,
            r.eta_minutes,
            r.rating,
            r.location_label,
            r.accent_color
        FROM menu_items m
        JOIN restaurants r ON r.id = m.restaurant_id
        WHERE {" AND ".join(conditions)}
        ORDER BY m.is_featured DESC, m.surplus_discount_percent DESC, r.rating DESC, m.prep_time_minutes ASC
    """
    rows = connection.execute(sql, params).fetchall()
    return [serialize_menu_item(row) for row in rows]


def build_recommendations(connection: sqlite3.Connection, profile_slug: str) -> list[dict[str, Any]]:
    profile = fetch_profile(connection, profile_slug)
    items = query_menu_items(connection, MenuFilters(profile=profile_slug))

    scored_items: list[tuple[float, dict[str, Any]]] = []
    for item in items:
        price_score = max(0, 1 - (item["discountedPrice"] / max(profile["budget_cap"], 1)))
        health_score = 1 if item["healthy"] else 0.35
        speed_score = max(0, 1 - (item["prepTime"] / 25))
        cuisine_score = 1 if item["restaurantCuisine"].lower() == profile["favorite_cuisine"].lower() else 0.4
        surplus_score = 0.2 if item["isSurplus"] else 0

        score = (
            (0.35 * price_score)
            + (profile["health_focus"] * 0.3 * health_score)
            + (profile["speed_focus"] * 0.2 * speed_score)
            + (0.1 * cuisine_score)
            + surplus_score
        )
        enriched = item | {
            "matchScore": round(score * 100, 1),
            "reason": recommendation_reason(item, profile),
        }
        scored_items.append((score, enriched))

    scored_items.sort(key=lambda pair: pair[0], reverse=True)
    return [item for _, item in scored_items[:4]]


def recommendation_reason(item: dict[str, Any], profile: sqlite3.Row) -> str:
    reasons: list[str] = []
    if item["discountedPrice"] <= profile["budget_cap"]:
        reasons.append("entra en tu presupuesto")
    if item["healthy"] and profile["health_focus"] >= 0.5:
        reasons.append("cumple tu enfoque saludable")
    if item["prepTime"] <= 10 and profile["speed_focus"] >= 0.5:
        reasons.append("sale muy rapido")
    if item["isSurplus"]:
        reasons.append("aprovecha oferta de excedente")
    return ", ".join(reasons[:2]) or "encaja con tu perfil actual"


def build_summary(connection: sqlite3.Connection) -> dict[str, Any]:
    total_items = connection.execute(
        "SELECT COUNT(*) AS total FROM menu_items WHERE inventory > 0"
    ).fetchone()["total"]
    open_restaurants = connection.execute(
        "SELECT COUNT(*) AS total FROM restaurants WHERE is_open = 1"
    ).fetchone()["total"]
    surplus = connection.execute(
        "SELECT COUNT(*) AS total FROM menu_items WHERE surplus_discount_percent > 0 AND inventory > 0"
    ).fetchone()["total"]
    fastest = connection.execute(
        """
        SELECT name, prep_time_minutes
        FROM menu_items
        WHERE inventory > 0
        ORDER BY prep_time_minutes ASC
        LIMIT 1
        """
    ).fetchone()
    return {
        "activeMenus": total_items,
        "openRestaurants": open_restaurants,
        "surplusDeals": surplus,
        "fastestDish": {
            "name": fastest["name"],
            "time": fastest["prep_time_minutes"],
        },
    }


def fetch_offers(connection: sqlite3.Connection) -> list[dict[str, Any]]:
    rows = connection.execute(
        """
        SELECT
            m.*,
            r.name AS restaurant_name,
            r.cuisine,
            r.eta_minutes,
            r.rating,
            r.location_label,
            r.accent_color
        FROM menu_items m
        JOIN restaurants r ON r.id = m.restaurant_id
        WHERE m.inventory > 0 AND m.surplus_discount_percent > 0
        ORDER BY m.surplus_discount_percent DESC, m.available_until ASC
        """
    ).fetchall()
    return [serialize_menu_item(row) for row in rows]


def create_preorder(connection: sqlite3.Connection, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        item_id = int(payload.get("menuItemId", 0))
        quantity = int(payload.get("quantity", 1))
    except (TypeError, ValueError):
        raise ValueError("Cantidad o ID de plato inválido.")

    quantity = max(1, min(5, quantity))
    customer_name = (payload.get("customerName") or "").strip()
    pickup_time = (payload.get("pickupTime") or "").strip()
    notes = (payload.get("notes") or "").strip()

    if not customer_name:
        raise ValueError("Por favor ingresa tu nombre.")
    if len(customer_name) < 3:
        raise ValueError("El nombre debe tener al menos 3 caracteres.")
    if not pickup_time:
        raise ValueError("Selecciona una hora de recogida.")
    if item_id <= 0:
        raise ValueError("Selecciona un plato del menú.")

    item = connection.execute(
        """
        SELECT m.*, r.name AS restaurant_name
        FROM menu_items m
        JOIN restaurants r ON r.id = m.restaurant_id
        WHERE m.id = ? AND m.inventory > 0
        """,
        (item_id,),
    ).fetchone()
    if item is None:
        raise ValueError("El plato seleccionado ya no está disponible.")

    if quantity > item["inventory"]:
        raise ValueError(f"Solo quedan {item['inventory']} unidades disponibles.")

    discount = item["surplus_discount_percent"] or 0
    unit_price = int(item["price_cop"] * (100 - discount) / 100)
    total_price = unit_price * quantity

    cursor = connection.execute(
        """
        INSERT INTO preorders
            (customer_name, menu_item_id, quantity, pickup_time, status, notes, total_price_cop, created_at)
        VALUES (?, ?, ?, ?, 'confirmada', ?, ?, ?)
        """,
        (
            customer_name,
            item_id,
            quantity,
            pickup_time,
            notes,
            total_price,
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    connection.execute(
        "UPDATE menu_items SET inventory = inventory - ? WHERE id = ?",
        (quantity, item_id),
    )
    connection.commit()

    return {
        "id": cursor.lastrowid,
        "customerName": customer_name,
        "restaurant": item["restaurant_name"],
        "itemName": item["name"],
        "quantity": quantity,
        "pickupTime": pickup_time,
        "status": "confirmada",
        "totalPrice": total_price,
        "totalPriceLabel": to_currency(total_price),
    }


class AppHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/api/health":
                self.respond_json({"status": "ok"})
                return
            if parsed.path == "/api/summary":
                connection = get_connection()
                try:
                    data = build_summary(connection)
                finally:
                    connection.close()
                self.respond_json(data)
                return
            if parsed.path == "/api/menu":
                filters = build_filters(parse_qs(parsed.query))
                connection = get_connection()
                try:
                    data = query_menu_items(connection, filters)
                finally:
                    connection.close()
                self.respond_json({"filters": asdict(filters), "items": data})
                return
            if parsed.path == "/api/recommendations":
                query = parse_qs(parsed.query)
                profile = (query.get("profile") or ["balance"])[0]
                connection = get_connection()
                try:
                    data = build_recommendations(connection, profile)
                    profiles = connection.execute(
                        "SELECT slug, label, dietary_tag FROM user_profiles ORDER BY id ASC"
                    ).fetchall()
                finally:
                    connection.close()
                self.respond_json(
                    {
                        "profile": profile,
                        "profiles": [dict(row) for row in profiles],
                        "items": data,
                    }
                )
                return
            if parsed.path == "/api/offers":
                connection = get_connection()
                try:
                    data = fetch_offers(connection)
                finally:
                    connection.close()
                self.respond_json({"items": data})
                return
            if parsed.path == "/" or parsed.path == "/index.html":
                self.serve_static("index.html")
                return
            if parsed.path.startswith("/static/"):
                relative_path = parsed.path.removeprefix("/static/")
                self.serve_static(relative_path)
                return
            self.send_error(HTTPStatus.NOT_FOUND, "Ruta no encontrada")
        except Exception as e:
            self.respond_json(
                {"error": f"Error interno: {str(e)}"},
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/preorders":
            self.send_error(HTTPStatus.NOT_FOUND, "Ruta no encontrada")
            return

        content_length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(content_length)
        try:
            payload = json.loads(raw_body.decode("utf-8"))
            connection = get_connection()
            response = create_preorder(connection, payload)
            connection.close()
        except ValueError as error:
            self.respond_json({"error": str(error)}, status=HTTPStatus.BAD_REQUEST)
            return
        except json.JSONDecodeError:
            self.respond_json({"error": "JSON invalido."}, status=HTTPStatus.BAD_REQUEST)
            return

        self.respond_json(response, status=HTTPStatus.CREATED)

    def serve_static(self, relative_path: str) -> None:
        requested = (STATIC_DIR / relative_path).resolve()
        if not str(requested).startswith(str(STATIC_DIR.resolve())) or not requested.exists():
            self.send_error(HTTPStatus.NOT_FOUND, "Archivo no encontrado")
            return

        content_types = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".ico": "image/x-icon",
        }
        content_type = content_types.get(requested.suffix, "text/plain; charset=utf-8")

        data = requested.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def respond_json(self, payload: Any, status: HTTPStatus = HTTPStatus.OK) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(encoded)

    def log_message(self, format: str, *args: Any) -> None:
        return


def run() -> None:
    initialize_database()
    server = ThreadingHTTPServer(("127.0.0.1", 8000), AppHandler)
    print("=" * 60)
    print("  🍴 Campus Food Hub")
    print("=" * 60)
    print("  Servidor activo en: http://127.0.0.1:8000")
    print("  Presiona Ctrl+C para detener")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 Servidor detenido")
    finally:
        server.server_close()


if __name__ == "__main__":
    run()
