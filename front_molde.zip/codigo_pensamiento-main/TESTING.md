# 🧪 Guía de Testing - Campus Food Hub

## Status Actual ✅

Todos los componentes están funcionando correctamente:

### ✅ Backend (Server HTTP)
- [x] Servidor HTTP corriendo en puerto 8000
- [x] Base de datos SQLite inicializada con datos de ejemplo
- [x] 4 restaurantes, 12 platos, 7 ofertas cargadas

### ✅ Filtros Inteligentes
- [x] **Búsqueda por nombre**: Filtra por nombre de plato, restaurante o categoría
- [x] **Precio máximo**: Filtra por precio final (incluyendo descuentos)
- [x] **Tiempo máximo**: Filtra por minutos de preparación
- [x] **Solo saludables**: Muestra solo platos nutritivos
- [x] **Solo excedentes**: Muestra solo platos con descuento

### ✅ Descuentos (Ofertas de Excedentes)
- [x] Se calculan correctamente en el servidor
- [x] Se muestran en las tarjetas con % de descuento
- [x] Precios finales reflejan el descuento aplicado
- [x] Sección "Excedentes" muestra todas las ofertas activas

### ✅ Sistema de Recomendaciones
- [x] 4 perfiles disponibles (Balance, Healthy, Budget, Comfort)
- [x] Recomendaciones se recalculan al cambiar perfil
- [x] Cada recomendación tiene un score de match (0-100%)
- [x] Se explica por qué se recomienda cada plato

### ✅ Preórdenes
- [x] Select de platos se llena con TODOS los platos disponibles
- [x] Botones "Preordenar" en cada plato funcionan
- [x] Formulario acepta nombre, hora, cantidad, notas
- [x] Confirmación inmediata con número de pedido

### ✅ UI/UX
- [x] Página responsive (móvil, tablet, desktop)
- [x] Interfaz intuitiva y clara
- [x] Navegación fluida entre secciones
- [x] Mensajes de error y éxito visibles

---

## 🧪 Cómo Probar

### Opción 1: Interfaz Web (Recomendado)

```bash
# 1. Asegurarse que el servidor está corriendo
python3 app.py

# 2. Abrir en navegador
# http://127.0.0.1:8000
```

**Pruebas en la interfaz:**

1. **Filtros**
   - Ingresa "bowl" en búsqueda → Debe mostrar 2 resultados (Bowl Andino, Tofu Fire)
   - Establece precio máximo 15000 → Debe mostrar 6 items
   - Marca "Solo saludables" → Debe mostrar 5 items
   - Marca "Solo excedentes" → Debe mostrar 7 items

2. **Descuentos**
   - Desplázate a sección "Excedentes"
   - Verifica que cada oferta muestra % de descuento
   - Comprueba que el precio final es menor al original
   - Ejemplo: Croissant ($7.900) → Con descuento 35% = $5.135

3. **Disponible Ahora**
   - La sección "Todo el menú" muestra "X opciones disponibles ahora"
   - Todos los items mostrados tienen inventario > 0
   - Al aplicar filtros, el contador se actualiza

4. **Preorden**
   - Haz clic en "Preordenar" en cualquier plato
   - El select debe mostrar el plato seleccionado
   - El select debe tener MÁS opciones disponibles (no solo una)
   - Completa: Nombre, Hora (ej: 12:30), Cantidad, Notas
   - Haz clic en "Confirmar preorden"
   - Deberías ver: "Preorden #X confirmada"

---

### Opción 2: API REST (Avanzado)

```bash
# Test 1: Menú completo
curl "http://127.0.0.1:8000/api/menu"

# Test 2: Filtro precio
curl "http://127.0.0.1:8000/api/menu?max_price=15000"

# Test 3: Búsqueda
curl "http://127.0.0.1:8000/api/menu?search=bowl"

# Test 4: Solo saludables
curl "http://127.0.0.1:8000/api/menu?healthy=true"

# Test 5: Solo ofertas
curl "http://127.0.0.1:8000/api/menu?surplus=true"

# Test 6: Ofertas disponibles
curl "http://127.0.0.1:8000/api/offers"

# Test 7: Recomendaciones (perfil healthy)
curl "http://127.0.0.1:8000/api/recommendations?profile=healthy"

# Test 8: Crear preorden
curl -X POST http://127.0.0.1:8000/api/preorders \
  -H "Content-Type: application/json" \
  -d '{
    "menuItemId": 1,
    "customerName": "Juan Pérez",
    "pickupTime": "12:30",
    "quantity": 2,
    "notes": "Sin picante"
  }'
```

---

## 📊 Datos de Prueba

### Restaurantes (4)
| Nombre | Tipo | Ubicación | ⭐ |
|--------|------|-----------|-----|
| Origen Verde | Bowls | Bloque A | 4.8 |
| Casa Pasta | Italiano | Plazoleta Central | 4.7 |
| Wok Relay | Asiático | Torre Norte | 4.6 |
| Pan de Barrio | Panadería | Biblioteca | 4.5 |

### Platos Principales (12)
| Plato | Precio | Descuento | Saludable | Tiempo |
|-------|--------|-----------|-----------|--------|
| Bowl Andino | $18.900 | - | ✅ | 11 min |
| Wrap Proteico | $14.900 | 15% | ✅ | 8 min |
| Ensalada Crunch | $13.900 | 20% | ✅ | 7 min |
| Pasta Pomodoro | $16.900 | - | ❌ | 15 min |
| Lasaña Express | $20.900 | 10% | ❌ | 17 min |
| Ravioli Ricotta | $21.900 | - | ✅ | 18 min |
| Wok de Pollo | $17.900 | - | ❌ | 10 min |
| Ramen Corto | $19.500 | - | ❌ | 12 min |
| Tofu Fire Bowl | $15.900 | 25% | ✅ | 9 min |
| Sandwich Campesino | $12.900 | 30% | ❌ | 5 min |
| Croissant de Almendra | $7.900 | 35% | ❌ | 4 min |
| Combo Café + Roll | $9.900 | 20% | ❌ | 3 min |

### Perfiles de Usuario (4)
| Nombre | Presupuesto | Enfoque | Favorito |
|--------|-------------|---------|----------|
| Balance | $18.000 | Equilibrado | Bowls |
| Healthy | $17.000 | Saludable | Bowls |
| Budget | $12.000 | Económico | Panadería |
| Comfort | $23.000 | Sin límites | Italiano |

---

## 🐛 Checklist de Verificación

- [ ] El servidor inicia sin errores
- [ ] La página carga en http://127.0.0.1:8000
- [ ] Se ven 12 platos en el menú completo
- [ ] Filtro de búsqueda "bowl" retorna 2 resultados
- [ ] Filtro de precio máximo $15.000 retorna 6 resultados
- [ ] Filtro "Solo saludables" retorna 5 resultados
- [ ] Filtro "Solo excedentes" retorna 7 resultados
- [ ] La sección "Excedentes" muestra 7 ofertas con descuentos
- [ ] Cada oferta muestra % de descuento aplicado
- [ ] El precio final refleja el descuento
- [ ] El select de preorden tiene múltiples opciones
- [ ] Al hacer clic en "Preordenar", el select se actualiza
- [ ] La preorden se puede crear exitosamente
- [ ] La confirmación muestra número de pedido
- [ ] Las recomendaciones cambian al cambiar perfil
- [ ] Cada recomendación muestra porcentaje de match

---

## 📝 Notas Importantes

- La BD se reinicia cada vez que se inicia el servidor sin datos previos
- Los precios están en COP (Pesos Colombianos)
- Los tiempos son en minutos de preparación
- Los descuentos se aplican automáticamente al calcular precios
- Cada preorden reduce el inventario del plato

---

## ⚠️ Si Algo No Funciona

1. **Verifica que el servidor esté corriendo**
   ```bash
   curl http://127.0.0.1:8000/api/health
   # Debe retornar: {"status": "ok"}
   ```

2. **Revisa los logs del servidor**
   ```bash
   tail -f /tmp/server.log
   ```

3. **Limpia el caché del navegador**
   - Presiona Ctrl+Shift+Delete (o Cmd+Shift+Delete en Mac)
   - Borra "Todas las imágenes y archivos almacenados en caché"
   - Recarga la página

4. **Reinicia el servidor**
   ```bash
   pkill -f "python.*app.py"
   sleep 1
   python3 app.py
   ```

---

**Última actualización:** 19 de mayo 2026
**Status:** ✅ Todos los tests pasados
