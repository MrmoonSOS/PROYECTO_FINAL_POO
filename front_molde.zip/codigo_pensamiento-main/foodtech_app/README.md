# FoodTech App

Aplicacion web de ejemplo para:

- Ver menu en tiempo real (polling cada 10 segundos)
- Filtrar por precio, salud y tiempo de preparacion
- Crear preordenes
- Obtener recomendaciones personalizadas por usuario
- Ver ofertas de excedentes

## Stack

- Backend/API: Flask + SQLite
- Frontend/UX: HTML, CSS, JavaScript vanilla
- Base de datos: SQLite (`foodtech.db`)

## Ejecutar localmente

1. Crear entorno virtual:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

2. Instalar dependencias:

```bash
pip install -r requirements.txt
```

3. Iniciar servidor:

```bash
python app.py
```

4. Abrir en navegador:

`http://127.0.0.1:5000`

## Endpoints API

- `GET /api/menu?max_price=&healthy_only=&max_prep_time=`
- `GET /api/offers/excedentes`
- `GET /api/recommendations/<user_id>`
- `POST /api/preorders`

### Ejemplo `POST /api/preorders`

```json
{
  "user_id": 1,
  "items": [
    { "menu_item_id": 1, "quantity": 2 },
    { "menu_item_id": 4, "quantity": 1 }
  ]
}
```
