import sqlite3
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request


BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "foodtech.db"

app = Flask(__name__)


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            preferred_category TEXT,
            health_focus INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS menu_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            price REAL NOT NULL,
            prep_time INTEGER NOT NULL,
            healthy INTEGER DEFAULT 0,
            stock INTEGER DEFAULT 0,
            is_surplus_offer INTEGER DEFAULT 0,
            last_updated TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            total REAL NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );

        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            menu_item_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders (id),
            FOREIGN KEY (menu_item_id) REFERENCES menu_items (id)
        );
        """
    )

    cur.execute("SELECT COUNT(*) as count FROM users")
    if cur.fetchone()["count"] == 0:
        cur.executemany(
            "INSERT INTO users (name, preferred_category, health_focus) VALUES (?, ?, ?)",
            [
                ("Simon", "Bowl", 1),
                ("Ana", "Wrap", 0),
                ("Carlos", "Ensalada", 1),
            ],
        )

    cur.execute("SELECT COUNT(*) as count FROM menu_items")
    if cur.fetchone()["count"] == 0:
        now = datetime.utcnow().isoformat()
        cur.executemany(
            """
            INSERT INTO menu_items
            (name, category, price, prep_time, healthy, stock, is_surplus_offer, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                ("Bowl de pollo", "Bowl", 18000, 12, 1, 15, 0, now),
                ("Wrap mediterraneo", "Wrap", 15000, 8, 1, 10, 0, now),
                ("Hamburguesa clasica", "Fast Food", 22000, 15, 0, 7, 0, now),
                ("Ensalada quinoa", "Ensalada", 17000, 10, 1, 12, 0, now),
                ("Pasta del dia", "Pasta", 16000, 14, 0, 9, 1, now),
                ("Sopa de vegetales", "Sopa", 12000, 7, 1, 20, 1, now),
            ],
        )

    conn.commit()
    conn.close()


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/menu")
def get_menu():
    max_price = request.args.get("max_price", type=float)
    healthy_only = request.args.get("healthy_only", default=0, type=int)
    max_prep_time = request.args.get("max_prep_time", type=int)

    query = "SELECT * FROM menu_items WHERE stock > 0"
    params = []

    if max_price is not None:
        query += " AND price <= ?"
        params.append(max_price)
    if healthy_only == 1:
        query += " AND healthy = 1"
    if max_prep_time is not None:
        query += " AND prep_time <= ?"
        params.append(max_prep_time)

    query += " ORDER BY last_updated DESC"

    conn = get_db_connection()
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.get("/api/offers/excedentes")
def get_surplus_offers():
    conn = get_db_connection()
    rows = conn.execute(
        """
        SELECT * FROM menu_items
        WHERE is_surplus_offer = 1 AND stock > 0
        ORDER BY price ASC
        """
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.get("/api/recommendations/<int:user_id>")
def get_recommendations(user_id):
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if user is None:
        conn.close()
        return jsonify({"error": "Usuario no encontrado"}), 404

    preferred_category = user["preferred_category"]
    health_focus = user["health_focus"]

    query = """
    SELECT * FROM menu_items
    WHERE stock > 0
      AND category = ?
    """
    params = [preferred_category]
    if health_focus:
        query += " AND healthy = 1"
    query += " ORDER BY prep_time ASC, price ASC LIMIT 5"

    rows = conn.execute(query, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.post("/api/preorders")
def create_preorder():
    payload = request.get_json(silent=True) or {}
    user_id = payload.get("user_id")
    items = payload.get("items", [])

    if not user_id or not items:
        return jsonify({"error": "Debe enviar user_id e items"}), 400

    conn = get_db_connection()
    cur = conn.cursor()
    user = cur.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
    if user is None:
        conn.close()
        return jsonify({"error": "Usuario no existe"}), 404

    total = 0
    validated_items = []

    for item in items:
        menu_item_id = item.get("menu_item_id")
        quantity = int(item.get("quantity", 0))
        if quantity <= 0:
            conn.close()
            return jsonify({"error": "Cantidad invalida en items"}), 400

        menu_item = cur.execute(
            "SELECT id, price, stock, name FROM menu_items WHERE id = ?",
            (menu_item_id,),
        ).fetchone()

        if menu_item is None:
            conn.close()
            return jsonify({"error": f"Item no encontrado: {menu_item_id}"}), 404
        if menu_item["stock"] < quantity:
            conn.close()
            return jsonify({"error": f"Sin stock suficiente para {menu_item['name']}"}), 400

        subtotal = menu_item["price"] * quantity
        total += subtotal
        validated_items.append(
            {
                "menu_item_id": menu_item["id"],
                "quantity": quantity,
                "unit_price": menu_item["price"],
            }
        )

    order_res = cur.execute(
        "INSERT INTO orders (user_id, total, status, created_at) VALUES (?, ?, ?, ?)",
        (user_id, total, "preordered", datetime.utcnow().isoformat()),
    )
    order_id = order_res.lastrowid

    for item in validated_items:
        cur.execute(
            """
            INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price)
            VALUES (?, ?, ?, ?)
            """,
            (order_id, item["menu_item_id"], item["quantity"], item["unit_price"]),
        )
        cur.execute(
            """
            UPDATE menu_items
            SET stock = stock - ?, last_updated = ?
            WHERE id = ?
            """,
            (item["quantity"], datetime.utcnow().isoformat(), item["menu_item_id"]),
        )

    conn.commit()
    conn.close()

    return jsonify(
        {
            "message": "Preorden creada con exito",
            "order_id": order_id,
            "total": total,
        }
    ), 201


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
