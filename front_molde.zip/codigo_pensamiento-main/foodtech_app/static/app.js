const menuList = document.getElementById("menuList");
const offersList = document.getElementById("offersList");
const recommendationsList = document.getElementById("recommendationsList");
const preorderItems = document.getElementById("preorderItems");
const preorderStatus = document.getElementById("preorderStatus");

const fmt = (value) =>
    new Intl.NumberFormat("es-CO", {
        style: "currency",
        currency: "COP",
        maximumFractionDigits: 0
    }).format(value);

let currentMenu = [];

function buildQuery() {
    const maxPrice = document.getElementById("maxPrice").value;
    const maxTime = document.getElementById("maxTime").value;
    const healthyOnly = document.getElementById("healthyOnly").checked ? "1" : "0";

    const query = new URLSearchParams();
    if (maxPrice) query.set("max_price", maxPrice);
    if (maxTime) query.set("max_prep_time", maxTime);
    query.set("healthy_only", healthyOnly);

    return query.toString();
}

function itemCard(item) {
    return `
        <div class="item">
            <div>
                <strong>${item.name}</strong>
                <div class="meta">${item.category} | ${item.prep_time} min | Stock: ${item.stock}</div>
            </div>
            <div><strong>${fmt(item.price)}</strong></div>
        </div>
    `;
}

async function loadMenu() {
    const query = buildQuery();
    const res = await fetch(`/api/menu?${query}`);
    currentMenu = await res.json();

    menuList.innerHTML = currentMenu.length
        ? currentMenu.map(itemCard).join("")
        : "<p>No hay opciones con esos filtros.</p>";

    preorderItems.innerHTML = currentMenu
        .map(
            (item) => `
            <label>
                ${item.name} (${fmt(item.price)})
                <input type="number" min="0" max="${item.stock}" value="0" data-item-id="${item.id}" />
            </label>
        `
        )
        .join("");
}

async function loadOffers() {
    const res = await fetch("/api/offers/excedentes");
    const offers = await res.json();
    offersList.innerHTML = offers.length
        ? offers.map(itemCard).join("")
        : "<p>No hay excedentes disponibles.</p>";
}

async function loadRecommendations() {
    const userId = document.getElementById("userSelect").value;
    const res = await fetch(`/api/recommendations/${userId}`);
    const data = await res.json();
    recommendationsList.innerHTML = data.length
        ? data.map(itemCard).join("")
        : "<p>No hay recomendaciones para este usuario.</p>";
}

async function submitPreorder() {
    const userId = Number(document.getElementById("userSelect").value);
    const inputs = preorderItems.querySelectorAll("input[data-item-id]");
    const items = [];

    inputs.forEach((input) => {
        const quantity = Number(input.value);
        if (quantity > 0) {
            items.push({
                menu_item_id: Number(input.dataset.itemId),
                quantity
            });
        }
    });

    if (!items.length) {
        preorderStatus.textContent = "Selecciona al menos un item para preordenar.";
        return;
    }

    const res = await fetch("/api/preorders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: userId, items })
    });
    const data = await res.json();

    if (!res.ok) {
        preorderStatus.textContent = `Error: ${data.error || "No se pudo crear la preorden"}`;
        return;
    }

    preorderStatus.textContent = `Preorden #${data.order_id} creada. Total: ${fmt(data.total)}.`;
    await loadMenu();
    await loadOffers();
}

document.getElementById("applyFilters").addEventListener("click", loadMenu);
document.getElementById("loadRecommendations").addEventListener("click", loadRecommendations);
document.getElementById("submitPreorder").addEventListener("click", submitPreorder);

loadMenu();
loadOffers();
loadRecommendations();
setInterval(loadMenu, 10000);
