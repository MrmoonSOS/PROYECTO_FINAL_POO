CREATE TABLE IF NOT EXISTS restaurants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    cuisine TEXT NOT NULL,
    eta_minutes INTEGER NOT NULL,
    health_score REAL NOT NULL,
    rating REAL NOT NULL,
    is_open INTEGER NOT NULL DEFAULT 1,
    location_label TEXT NOT NULL,
    accent_color TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS menu_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    restaurant_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    price_cop INTEGER NOT NULL,
    category TEXT NOT NULL,
    calories INTEGER NOT NULL,
    prep_time_minutes INTEGER NOT NULL,
    is_healthy INTEGER NOT NULL DEFAULT 0,
    inventory INTEGER NOT NULL DEFAULT 0,
    surplus_discount_percent INTEGER NOT NULL DEFAULT 0,
    available_until TEXT,
    is_featured INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
);

CREATE TABLE IF NOT EXISTS user_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT NOT NULL UNIQUE,
    label TEXT NOT NULL,
    budget_cap INTEGER NOT NULL,
    health_focus REAL NOT NULL,
    speed_focus REAL NOT NULL,
    favorite_cuisine TEXT NOT NULL,
    dietary_tag TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS preorders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    menu_item_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    pickup_time TEXT NOT NULL,
    status TEXT NOT NULL,
    notes TEXT,
    total_price_cop INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
);
