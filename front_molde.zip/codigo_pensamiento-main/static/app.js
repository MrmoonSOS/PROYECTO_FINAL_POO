// ===== Estado global =====
const state = {
  profile: "balance",
  menuItems: [],
  profiles: [],
  itemsById: {},
};

// ===== Referencias del DOM =====
const $ = (id) => document.getElementById(id);

const summaryCards = $("summaryCards");
const profileSelect = $("profileSelect");
const profileHint = $("profileHint");
const menuGrid = $("menuGrid");
const offersGrid = $("offers");
const recommendationsGrid = $("recommendations");
const menuCount = $("menuCount");
const menuItemSelect = $("menuItemSelect");
const preorderForm = $("preorderForm");
const preorderMessage = $("preorderMessage");
const preorderTotal = $("preorderTotal");
const preorderSummary = $("preorderSummary");
const clearFiltersBtn = $("clearFilters");
const modalBackdrop = $("modalBackdrop");
const modalDetails = $("modalDetails");
const modalClose = $("modalClose");
const quantityInput = $("quantity");

const filterInputs = {
  search: $("searchInput"),
  maxPrice: $("priceInput"),
  maxTime: $("timeInput"),
  healthy: $("healthyInput"),
  surplus: $("surplusInput"),
};

let filterTimeout;

// ===== Utilidades =====
function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function formatCOP(value) {
  return "$" + Number(value).toLocaleString("es-CO");
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error("Error de comunicación con el servidor");
  }
  if (!response.ok) {
    throw new Error(data.error || "Algo salió mal.");
  }
  return data;
}

// ===== Renderizado de tarjetas =====
function buildCard(item, mode = "menu") {
  const priceBlock = item.isSurplus
    ? `<div class="price-row">
         <span class="price-current">${item.discountedPriceLabel}</span>
         <span class="price-original">${item.priceLabel}</span>
       </div>`
    : `<div class="price-row">
         <span class="price-current">${item.priceLabel}</span>
       </div>`;

  const reason = item.reason
    ? `<p class="recommendation-reason">${escapeHtml(item.reason)}</p>`
    : "";

  const matchBadge = mode === "recommendation" && item.matchScore != null
    ? `<div class="match-score">${Math.round(item.matchScore)}%</div>`
    : "";

  const actionLabel = mode === "recommendation" ? "Quiero este →" : "Preordenar →";

  const tagsHtml = `
    ${item.healthy ? '<span class="tag-badge tag-healthy">✓ Saludable</span>' : ""}
    ${item.featured ? '<span class="tag-badge tag-top">★ Top</span>' : ""}
    ${item.isSurplus ? `<span class="tag-badge tag-surplus">-${item.surplusDiscount}% oferta</span>` : ""}
  `;

  return `
    <article class="card" data-card-id="${item.id}">
      ${matchBadge}
      <div class="card-header">
        <div class="card-title-block">
          <h3>${escapeHtml(item.name)}</h3>
          <p class="restaurant-name">${escapeHtml(item.restaurant)}</p>
        </div>
        <span class="card-category" style="background:${escapeHtml(item.restaurantAccent)}">${escapeHtml(item.category)}</span>
      </div>
      <p class="card-description">${escapeHtml(item.description)}</p>
      <div class="meta-row">
        <span class="tag tag-time">${item.prepTime} min</span>
        <span class="tag tag-cal">${item.calories} kcal</span>
        <span class="tag tag-loc">${escapeHtml(item.restaurantLocation)}</span>
      </div>
      <div class="tags-row">${tagsHtml}</div>
      ${priceBlock}
      ${reason}
      <button data-item-id="${item.id}" class="pick-item">${actionLabel}</button>
    </article>
  `;
}

function buildOfferCard(item) {
  const savings = item.price - item.discountedPrice;
  const availableUntil = item.availableUntil
    ? `Hasta las ${item.availableUntil}`
    : "Hasta agotar stock";

  return `
    <article class="offer-card" data-card-id="${item.id}">
      <div class="offer-discount-badge">-${item.surplusDiscount}%</div>
      <h3>${escapeHtml(item.name)}</h3>
      <p class="offer-restaurant">${escapeHtml(item.restaurant)} · ${escapeHtml(item.restaurantLocation)}</p>
      <p class="offer-description">${escapeHtml(item.description)}</p>
      <div class="offer-pricing">
        <div class="offer-prices">
          <span class="offer-price-current">${item.discountedPriceLabel}</span>
          <span class="offer-price-original">${item.priceLabel}</span>
        </div>
        <div class="offer-savings">
          Ahorras<br>
          <strong>${formatCOP(savings)}</strong>
          <small>${availableUntil}</small>
        </div>
      </div>
      <button data-item-id="${item.id}" class="pick-item">⭐ Reservar oferta</button>
    </article>
  `;
}

// ===== Renderizado de secciones =====
function renderSummary(summary) {
  summaryCards.innerHTML = `
    <div class="stat-card">
      <strong>${summary.activeMenus}</strong>
      <span>platos activos</span>
    </div>
    <div class="stat-card">
      <strong>${summary.openRestaurants}</strong>
      <span>restaurantes abiertos</span>
    </div>
    <div class="stat-card">
      <strong>${summary.surplusDeals}</strong>
      <span>ofertas anti-desperdicio</span>
    </div>
    <div class="stat-card">
      <strong>${summary.fastestDish.time}<span style="font-size:0.6em;opacity:0.7">min</span></strong>
      <span>más rápido: ${escapeHtml(summary.fastestDish.name)}</span>
    </div>
  `;
}

function renderProfiles(profiles, selected) {
  state.profiles = profiles;
  profileSelect.innerHTML = profiles
    .map((p) => `<option value="${p.slug}" ${p.slug === selected ? "selected" : ""}>${escapeHtml(p.label)}</option>`)
    .join("");

  const current = profiles.find((p) => p.slug === selected);
  profileHint.textContent = current ? `Enfoque: ${current.dietary_tag}` : "";
}

function renderMenu(items) {
  state.menuItems = items;
  items.forEach((it) => { state.itemsById[it.id] = it; });

  const activeFilters = [];
  if (filterInputs.search.value.trim()) activeFilters.push(`"${filterInputs.search.value.trim()}"`);
  if (filterInputs.maxPrice.value) activeFilters.push(`≤ ${formatCOP(filterInputs.maxPrice.value)}`);
  if (filterInputs.maxTime.value) activeFilters.push(`≤ ${filterInputs.maxTime.value} min`);
  if (filterInputs.healthy.checked) activeFilters.push("saludables");
  if (filterInputs.surplus.checked) activeFilters.push("ofertas");

  let countText = `${items.length} ${items.length === 1 ? "plato disponible" : "platos disponibles"}`;
  if (activeFilters.length > 0) {
    countText += ` · filtrando por: ${activeFilters.join(", ")}`;
  }
  menuCount.textContent = countText;

  if (items.length === 0) {
    menuGrid.innerHTML = '<div class="empty-state">No encontramos platos con esos filtros.<br>Prueba ampliando presupuesto o tiempo.</div>';
    menuItemSelect.innerHTML = '<option value="">Sin opciones disponibles</option>';
    updatePreorderSummary();
    return;
  }

  menuGrid.innerHTML = items.map((item) => buildCard(item)).join("");

  const currentSelected = menuItemSelect.value;
  menuItemSelect.innerHTML =
    '<option value="">Selecciona un plato...</option>' +
    items.map((item) => {
      const price = item.isSurplus ? item.discountedPriceLabel : item.priceLabel;
      const label = `${item.name} · ${item.restaurant} · ${price}`;
      return `<option value="${item.id}">${escapeHtml(label)}</option>`;
    }).join("");

  if (currentSelected && items.some(i => String(i.id) === currentSelected)) {
    menuItemSelect.value = currentSelected;
  }
  updatePreorderSummary();
}

function renderRecommendations(items) {
  items.forEach((it) => { state.itemsById[it.id] = it; });
  if (items.length === 0) {
    recommendationsGrid.innerHTML = '<div class="empty-state">Aún no hay recomendaciones para este perfil.</div>';
    return;
  }
  recommendationsGrid.innerHTML = items.map((item) => buildCard(item, "recommendation")).join("");
}

function renderOffers(items) {
  items.forEach((it) => { state.itemsById[it.id] = it; });
  if (items.length === 0) {
    offersGrid.innerHTML = '<div class="empty-state">No hay ofertas activas por ahora.<br>¡Vuelve más tarde!</div>';
    return;
  }
  offersGrid.innerHTML = items.map(buildOfferCard).join("");
}

// ===== Resumen de preorden en vivo =====
function updatePreorderSummary() {
  const id = menuItemSelect.value;
  const qty = Math.max(1, Number(quantityInput.value) || 1);

  if (!id || !state.itemsById[id]) {
    preorderSummary.querySelector(".preorder-summary-label").textContent = "Selecciona un plato para ver el total";
    preorderTotal.textContent = "—";
    return;
  }

  const item = state.itemsById[id];
  const unitPrice = item.isSurplus ? item.discountedPrice : item.price;
  const total = unitPrice * qty;
  const label = qty > 1
    ? `${qty}× ${item.name} (${formatCOP(unitPrice)} c/u)`
    : `${item.name}`;

  preorderSummary.querySelector(".preorder-summary-label").textContent = label;
  preorderTotal.textContent = formatCOP(total);
}

// ===== Query builder =====
function currentMenuQuery() {
  const params = new URLSearchParams();
  if (filterInputs.search.value.trim()) params.set("search", filterInputs.search.value.trim());
  if (filterInputs.maxPrice.value) params.set("max_price", filterInputs.maxPrice.value);
  if (filterInputs.maxTime.value) params.set("max_time", filterInputs.maxTime.value);
  if (filterInputs.healthy.checked) params.set("healthy", "true");
  if (filterInputs.surplus.checked) params.set("surplus", "true");
  params.set("profile", state.profile);
  return params.toString();
}

// ===== Loaders =====
async function loadSummary() {
  try {
    const summary = await fetchJson("/api/summary");
    renderSummary(summary);
  } catch (e) {
    console.error("Error cargando resumen:", e);
  }
}

async function loadRecommendations() {
  try {
    const data = await fetchJson(`/api/recommendations?profile=${encodeURIComponent(state.profile)}`);
    renderProfiles(data.profiles, state.profile);
    renderRecommendations(data.items);
  } catch (e) {
    recommendationsGrid.innerHTML = `<div class="empty-state">No se pudieron cargar las recomendaciones.</div>`;
  }
}

async function loadOffers() {
  try {
    const data = await fetchJson("/api/offers");
    renderOffers(data.items);
  } catch (e) {
    offersGrid.innerHTML = `<div class="empty-state">No se pudieron cargar las ofertas.</div>`;
  }
}

async function loadMenu() {
  try {
    const query = currentMenuQuery();
    const data = await fetchJson(`/api/menu?${query}`);
    renderMenu(data.items);
  } catch (error) {
    menuGrid.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
    menuItemSelect.innerHTML = '<option value="">Error cargando</option>';
  }
}

async function refreshAll() {
  await Promise.all([loadSummary(), loadRecommendations(), loadOffers(), loadMenu()]);
}

// ===== Modal =====
function openModal(data) {
  modalDetails.innerHTML = `
    <div class="row"><span>Pedido N°</span><span>#${data.id}</span></div>
    <div class="row"><span>Plato</span><span>${escapeHtml(data.itemName)}</span></div>
    <div class="row"><span>Restaurante</span><span>${escapeHtml(data.restaurant)}</span></div>
    <div class="row"><span>Cliente</span><span>${escapeHtml(data.customerName)}</span></div>
    <div class="row"><span>Cantidad</span><span>${data.quantity}</span></div>
    <div class="row"><span>Recoger a las</span><span>${escapeHtml(data.pickupTime)}</span></div>
    <div class="row total"><span>Total a pagar</span><span>${data.totalPriceLabel}</span></div>
  `;
  modalBackdrop.classList.add("open");
}

function closeModal() {
  modalBackdrop.classList.remove("open");
}

// ===== Submit de preorden =====
async function submitPreorder(event) {
  event.preventDefault();
  preorderMessage.textContent = "Procesando tu preorden...";
  preorderMessage.className = "form-message processing";

  try {
    if (!menuItemSelect.value) {
      throw new Error("Selecciona un plato del menú.");
    }

    const payload = {
      menuItemId: Number(menuItemSelect.value),
      customerName: $("customerName").value.trim(),
      pickupTime: $("pickupTime").value,
      quantity: Number($("quantity").value),
      notes: $("notes").value.trim(),
    };

    const data = await fetchJson("/api/preorders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    preorderMessage.textContent = `✓ Preorden #${data.id} confirmada exitosamente.`;
    preorderMessage.className = "form-message success";

    openModal(data);

    preorderForm.reset();
    quantityInput.value = 1;
    await refreshAll();
    updatePreorderSummary();
  } catch (error) {
    preorderMessage.textContent = "⚠ " + error.message;
    preorderMessage.className = "form-message error";
  }
}

// ===== Event delegation =====
document.addEventListener("click", (event) => {
  const btn = event.target.closest(".pick-item");
  if (btn) {
    const itemId = btn.dataset.itemId;
    menuItemSelect.value = itemId;
    updatePreorderSummary();
    document.getElementById("preorden").scrollIntoView({ behavior: "smooth", block: "start" });
    $("customerName").focus({ preventScroll: true });
  }
});

// ===== Filtros automáticos =====
function setupFilterListeners() {
  ["searchInput", "priceInput", "timeInput"].forEach((id) => {
    const input = document.getElementById(id);
    if (input) {
      input.addEventListener("input", () => {
        clearTimeout(filterTimeout);
        filterTimeout = setTimeout(loadMenu, 350);
      });
    }
  });

  ["healthyInput", "surplusInput"].forEach((id) => {
    const input = document.getElementById(id);
    if (input) {
      input.addEventListener("change", loadMenu);
    }
  });
}

// ===== Botón limpiar filtros =====
clearFiltersBtn.addEventListener("click", () => {
  filterInputs.search.value = "";
  filterInputs.maxPrice.value = "";
  filterInputs.maxTime.value = "";
  filterInputs.healthy.checked = false;
  filterInputs.surplus.checked = false;
  loadMenu();
});

// ===== Cambios en el form de preorden =====
menuItemSelect.addEventListener("change", updatePreorderSummary);
quantityInput.addEventListener("input", updatePreorderSummary);

// ===== Perfil =====
profileSelect.addEventListener("change", async (event) => {
  state.profile = event.target.value;
  await Promise.all([loadRecommendations(), loadMenu()]);
});

// ===== Modal close handlers =====
modalClose.addEventListener("click", closeModal);
modalBackdrop.addEventListener("click", (e) => {
  if (e.target === modalBackdrop) closeModal();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeModal();
});

// ===== Submit del form =====
preorderForm.addEventListener("submit", submitPreorder);

// ===== Inicializar =====
setupFilterListeners();
refreshAll().catch((error) => {
  menuGrid.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
});
