# Campus Food Hub 🍜

Un sistema de gestión de comidas para campus universitarios que permite descubrir platos, filtrar por preferencias personales y realizar preórdenes sin hacer filas.

## Características principales

✨ **Menú en tiempo real**
- 12+ platos disponibles de 4 restaurantes del campus
- Filtros inteligentes por precio, tiempo de preparación y salud
- Búsqueda en tiempo real

🎯 **Recomendaciones personalizadas**
- 4 perfiles de usuario: Balance, Fit Rápido, Ahorro Total, Antojo del día
- Sistema de puntuación basado en presupuesto, salud, velocidad y preferencias
- Recomendaciones actualizadas según el perfil seleccionado

💰 **Ofertas anti-desperdicio**
- Descuentos en excedentes de comida
- Hasta 35% de descuento en seleccionados
- Información de disponibilidad

📋 **Sistema de preórdenes**
- Reserva instantánea con nombre y hora de recogida
- Notas personalizadas (sin cebolla, extra salsa, etc.)
- Confirmación inmediata con número de pedido

## Tecnología

**Backend:**
- Python 3.x
- SQLite para persistencia de datos
- Servidor HTTP personalizado (sin frameworks)

**Frontend:**
- HTML5 semántico
- CSS moderno con variables y gradientes
- JavaScript vanilla con fetch API
- Diseño responsive (mobile, tablet, desktop)

**Datos:**
- 4 restaurantes (Origen Verde, Casa Pasta, Wok Relay, Pan de Barrio)
- 12 platos con información nutricional completa
- Perfiles de usuario configurables

## Cómo ejecutar

### Requisitos
- Python 3.8 o superior
- Ninguna dependencia externa (built-in libraries only)

### Pasos

1. **Clonar o descargar el proyecto**
```bash
cd /ruta/al/proyecto
```

2. **Ejecutar el servidor**
```bash
python app.py
```

Deberías ver el mensaje:
```
Campus Food Hub disponible en http://127.0.0.1:8000
```

3. **Abrir en el navegador**
- Abre tu navegador en: **http://127.0.0.1:8000**
- La interfaz se cargará automáticamente

4. **Detener el servidor**
- Presiona `Ctrl+C` en la terminal

## Cómo usar

### 1. Explorar el menú
- La página principal muestra estadísticas: platos activos, restaurantes abiertos, ofertas disponibles
- Desplázate hacia abajo para ver todas las opciones

### 2. Cambiar tu perfil
En la sección superior derecha, selecciona tu perfil:
- **Balance diario**: Precio y salud equilibrados ($18k, proteína media)
- **Fit rápido**: Enfocado en opciones saludables ($17k, alta proteína)
- **Ahorro total**: Opciones económicas ($12k, cualquier tipo)
- **Antojo del día**: Sin restricciones, comidas más abundantes ($23k)

Las recomendaciones cambiarán automáticamente.

### 3. Filtrar platos
Usa los filtros inteligentes para refinar:
- **Buscar**: Por nombre del plato, restaurante o categoría
- **Precio máximo**: COP (pesos colombianos)
- **Tiempo máximo**: Minutos de preparación
- **Solo saludables**: Filtra platos etiquetados como nutritivos
- **Solo excedentes**: Ver solo ofertas con descuento

### 4. Hacer una preorden
1. Haz clic en "Preordenar" en cualquier plato
2. Completa el formulario:
   - **Plato**: Se preselecciona automáticamente
   - **Tu nombre**: Nombre completo
   - **Hora de recogida**: Ej. 12:30
   - **Cantidad**: 1-5 unidades
   - **Notas**: Personalizaciones opcionales
3. Haz clic en "Confirmar preorden"
4. Recibirás confirmación con número de pedido y total

## Estructura del proyecto

```
codigo_pensamiento/
├── app.py                 # Servidor HTTP principal + API
├── schema.sql             # Definición de base de datos
├── campus_food.db         # Base de datos SQLite (auto-generada)
├── static/
│   ├── index.html         # Interfaz HTML
│   ├── app.js             # Lógica JavaScript
│   └── styles.css         # Estilos CSS
└── README.md              # Este archivo
```

## API Endpoints

El servidor expone estos endpoints RESTful:

### GET `/api/health`
Estado del servidor
```json
{"status": "ok"}
```

### GET `/api/summary`
Estadísticas generales
```json
{
  "activeMenus": 12,
  "openRestaurants": 4,
  "surplusDeals": 7,
  "fastestDish": {"name": "Combo Cafe + Roll", "time": 3}
}
```

### GET `/api/menu?search=bowl&max_price=20000&healthy=true`
Lista de platos con filtros
- `search`: Buscar por nombre
- `max_price`: Precio máximo (COP)
- `max_time`: Tiempo máximo (minutos)
- `healthy`: Solo saludables (true/false)
- `surplus`: Solo ofertas (true/false)
- `profile`: Perfil de usuario

### GET `/api/recommendations?profile=balance`
Recomendaciones personalizadas
- `profile`: balance | healthy | budget | comfort

### GET `/api/offers`
Todas las ofertas activas

### POST `/api/preorders`
Crear una preorden
```json
{
  "menuItemId": 5,
  "customerName": "Juan Pérez",
  "pickupTime": "12:30",
  "quantity": 2,
  "notes": "Sin picante"
}
```

## Datos de ejemplo

**Restaurantes:**
- Origen Verde (Bowls) - Bloque A - ⭐ 4.8
- Casa Pasta (Italiano) - Plazoleta Central - ⭐ 4.7
- Wok Relay (Asiático) - Torre Norte - ⭐ 4.6
- Pan de Barrio (Panadería) - Biblioteca - ⭐ 4.5

**Platos populares:**
- Bowl Andino ($18,900 | 11 min | Saludable)
- Lasaña Express ($20,900 | 17 min | Especial)
- Wok de Pollo ($17,900 | 10 min | Destacado)
- Sandwich Campesino ($12,900 | 5 min | Rápido)

## Personalización

Para agregar más restaurantes o platos:

1. Edita la función `seed_database()` en `app.py`
2. Agrega tuplas a las listas `restaurants` o `menu_items`
3. Reinicia el servidor (la DB se recreará si está vacía)

Para cambiar el puerto:

1. En `app.py`, línea 469, cambia `("127.0.0.1", 8000)` a tu puerto deseado
2. Reinicia el servidor

## Notas de desarrollo

- No requiere npm, pip install, ni configuración compleja
- La base de datos se crea automáticamente en primera ejecución
- El servidor es thread-safe y puede manejar múltiples conexiones simultaneas
- Los precios están en COP (pesos colombianos)
- Los tiempos de preparación incluyen tiempo de espera estimado

## Troubleshooting

**"Connection refused" al abrir localhost:8000**
- Verifica que `python app.py` esté ejecutándose
- Comprueba con `curl http://127.0.0.1:8000/api/health`

**"Faltan datos obligatorios" en preorden**
- Asegúrate de completar todos los campos
- Verifica que seleccionaste una hora válida

**Los filtros no funcionan**
- Abre la consola (F12 en navegador)
- Verifica que no hay errores en network

**Puerto 8000 en uso**
- Usa `lsof -i :8000` para encontrar el proceso
- Cambia el puerto en `app.py` línea 469

## Créditos

Desarrollado para Campus Food Hub 2025 con ❤️ para reducir desperdicio y mejorar la experiencia de comida en campus.      
